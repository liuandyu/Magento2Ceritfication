<?php 

namespace Priyank\Example\Model;

//use Priyank\Example\Model\ModelThree;

class ModelFour extends ModelThree{
    
//    private $modelThree;
//
//
//    public function __construct(ModelThree $modelThree) {
//        $this->modelThree = $modelThree;
//    }
//    
//    public function getClassInfo(){
//        return get_class($this->modelThree);
//    }
    
    public function sayHi(){
        return "Hi from Model Four";
    }
    
}