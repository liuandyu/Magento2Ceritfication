<?php 

namespace Priyank\Example\Model;

class ModelOne{
    
    public $modelTwo;


    public function __construct(ModelTwo $modelTwo) {
        $this->modelTwo = $modelTwo;
    }
    
    public function getHi(){
        return $this->modelTwo->getHi();
    }


//    public function getCurrentClassInfo(){
//        return get_class($this->modelTwo);
//    }
//    
//    public function getClassInfo(){
//        return $this->modelTwo->getClassInfo();
//    }    
    
}