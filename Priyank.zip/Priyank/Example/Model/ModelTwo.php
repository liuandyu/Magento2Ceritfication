<?php 

namespace Priyank\Example\Model;

class ModelTwo{
    
    public $modelThree;


    public function __construct(ModelThree $modelThree) {
        $this->modelThree = $modelThree;
    }
    
    public function getHi(){
        return $this->modelThree->sayHi();
    }


//    public function getClassInfo(){
//        return get_class($this->modelThree);
//    }
    
}