<?php 

namespace Priyank\Example\Model;

use Priyank\Example\Model\ModelTwo;
use Priyank\Example\Model\ModelFour;

class ModelFive{
    
//
//
    public function __construct(ModelFour $modelThree) {
        //parent::__construct($modelThree);
    }
    
    public function sayHi(){
        return "Hi from Model Four";
    }
    
}