<?php

namespace Priyank\Example\Controller\Index;

use Priyank\Example\Model\ModelOne;
use Magento\Framework\ObjectManagerInterface;

class Index extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
    
    private $modelOne;
    
    private $objectManager;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        ObjectManagerInterface $objectManager
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->objectManager = $objectManager;
        parent::__construct($context);
    }
    
    protected function getObjectManager()
    {
        return $this->objectManager;
    }    

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $object_manager = $this->getObjectManager();        
        $modelOne = $object_manager->create('Priyank\Example\Model\ModelOne');
        $properties = get_object_vars($modelOne);        
        foreach($properties as $name=>$property)
        {
            $this->reportOnVariable($name, $property);       
        }
        
        echo "<br/> Next, we're going to report on the ModelOne object's one property (an ModelTwo class) <br/>";  
        $properties     = get_object_vars($modelOne->modelTwo);        
        foreach($properties as $name=>$property)
        {
            $this->reportOnVariable($name, $property);       
        }
        echo $modelOne->getHi();
        
        echo "<br/><br/> Finally, we'll report on an ModelTwo object, instantiated seperate from Example <br/>";          
        $modelTwo  = $object_manager->create('Priyank\Example\Model\ModelTwo');
        $properties = get_object_vars($modelTwo);        
        foreach($properties as $name=>$property)
        {
            $this->reportOnVariable($name, $property);       
        }
        echo $modelTwo->getHi();
        die;
        return $this->resultPageFactory->create();
    }
    
    protected function reportOnVariable($name, $thing)
    {
        echo 'The Property $' . $name;
        $type = gettype($thing);
        $aoran   = $this->getAOrAn($type);
        echo '  is '.$aoran.' ' . $type;
        call_user_func([$this,'outputValueOf'.ucwords($type)],$thing);
        echo "<br/>";
        //$this->output('');        
    }  

    protected function getAOrAn($string)
    {
        if(in_array($string[0], ['a','e','i','o','u']))
        {
            return 'an';
        }
        return 'a';
    }

    protected function outputValueOfObject($thing)
    {
        echo '  created with the class: ';
        echo '  ' . get_class($thing);
        
    }

    protected function outputValueOfString($thing)
    {
        echo '  with a value of: ' . $thing;
    }    
    
    protected function outputValueOfInteger($thing)
    {
        echo '  with a value of: ' . $thing;
    }    
    
    protected function outputValueOfBoolean($thing)
    {
        echo '  with a value of: ' . ($thing ? 'true' : 'false');
    }        

//    protected function outputValueOfArray($thing)
//    {
//        $this->output('  with the elements: ');
//        foreach($thing as $key=>$value)
//        {
//            $this->output('  ' . $key . '=>' . $value);
//        }
//    }                    
}
