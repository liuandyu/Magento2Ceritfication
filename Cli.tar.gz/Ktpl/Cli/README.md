CLI Command

php bin/magento example:modules:check-active

php bin/magento example:greeting Pratik